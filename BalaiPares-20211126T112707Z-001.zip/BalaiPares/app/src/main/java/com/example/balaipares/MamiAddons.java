package com.example.balaipares;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MamiAddons extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mami_addons);
    }
}